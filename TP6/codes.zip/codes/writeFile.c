#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <time.h>


int main (int argc, char **argv){

   if (argc < 3){
	printf (" Usage %s <fichierAEcrire> <nombre de blocks> \n", argv[0]); 
	exit(0);
   } 
    char cmd[256]; 
 
    // ***  A compléter => Recouverture du code par la commande qui écrire un fichier d'une certaine taille

   
   return  EXIT_FAILURE;  
}
